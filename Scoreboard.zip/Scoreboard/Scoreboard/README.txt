Scoreboard v5 - UI tuned to match provided image. Use Visual Studio to open solution and restore NuGet packages.
Default admin: admin/admin123
