using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;
using MaterialSkin.Controls;
using Scoreboard.Config;
using Scoreboard.Data;
using Scoreboard.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Scoreboard
{
    public class AddUpdateMatch : Form
    {
        private System.Windows.Forms.TextBox txtTeam1;
        private System.Windows.Forms.TextBox txtTeam2;
        private Label lblTeam2;
        private Label lblName;
        private MaterialButton btnCancel;
        private MaterialButton btnSave;
        private Label lblTrongTai;
        private CheckedListBox clbReferees; // Đã thay đổi từ ComboBox sang CheckedListBox để chọn nhiều
        private System.Windows.Forms.TextBox txtRefereeSearch; // Added search textbox for referees
        private Label lblTeam1;
        private Label lblMatch_Id;
        private Label lblNote;
        private System.Windows.Forms.TextBox txtnote;
        private MatchModel currentMatch;
        private List<UserModel> allUsers; // Lưu trữ tất cả người dùng để tham khảo
        private Label lblStartDateTime;
        private DateTimePicker dtpStartDateTime;
        private Label lblEndDateTime;
        private DateTimePicker dtpEndDateTime;
        private Label lblStatus;
        private System.Windows.Forms.ComboBox cbStatus;
        private PictureBox pbTeam1Flag;
        private PictureBox pbTeam2Flag;
        private Label lblId1;
        private Label lblournamentsId1;
        private Label lblournamentsId2;
        private Label lblId2;
        private OpenFileDialog openFileDialog;

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddUpdateMatch));
            this.txtTeam1 = new System.Windows.Forms.TextBox();
            this.lblTeam1 = new System.Windows.Forms.Label();
            this.txtTeam2 = new System.Windows.Forms.TextBox();
            this.lblTeam2 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnCancel = new MaterialSkin.Controls.MaterialButton();
            this.btnSave = new MaterialSkin.Controls.MaterialButton();
            this.lblTrongTai = new System.Windows.Forms.Label();
            this.clbReferees = new System.Windows.Forms.CheckedListBox();
            this.txtRefereeSearch = new System.Windows.Forms.TextBox();
            this.lblMatch_Id = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.txtnote = new System.Windows.Forms.TextBox();
            this.lblStartDateTime = new System.Windows.Forms.Label();
            this.dtpStartDateTime = new System.Windows.Forms.DateTimePicker();
            this.lblEndDateTime = new System.Windows.Forms.Label();
            this.dtpEndDateTime = new System.Windows.Forms.DateTimePicker();
            this.lblStatus = new System.Windows.Forms.Label();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.pbTeam1Flag = new System.Windows.Forms.PictureBox();
            this.pbTeam2Flag = new System.Windows.Forms.PictureBox();
            this.lblId1 = new System.Windows.Forms.Label();
            this.lblournamentsId1 = new System.Windows.Forms.Label();
            this.lblournamentsId2 = new System.Windows.Forms.Label();
            this.lblId2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbTeam1Flag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTeam2Flag)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTeam1
            // 
            this.txtTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTeam1.Location = new System.Drawing.Point(148, 82);
            this.txtTeam1.MaxLength = 100;
            this.txtTeam1.Name = "txtTeam1";
            this.txtTeam1.ReadOnly = true;
            this.txtTeam1.Size = new System.Drawing.Size(303, 26);
            this.txtTeam1.TabIndex = 3;
            this.txtTeam1.Text = "Tìm kiếm đội...";
            this.txtTeam1.DoubleClick += new System.EventHandler(this.txtTeam1_DoubleClick);
            // 
            // lblTeam1
            // 
            this.lblTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam1.ForeColor = System.Drawing.Color.Blue;
            this.lblTeam1.Location = new System.Drawing.Point(229, 29);
            this.lblTeam1.Name = "lblTeam1";
            this.lblTeam1.Size = new System.Drawing.Size(124, 50);
            this.lblTeam1.TabIndex = 2;
            this.lblTeam1.Text = "Đội 1";
            this.lblTeam1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTeam2
            // 
            this.txtTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTeam2.Location = new System.Drawing.Point(466, 82);
            this.txtTeam2.MaxLength = 100;
            this.txtTeam2.Name = "txtTeam2";
            this.txtTeam2.ReadOnly = true;
            this.txtTeam2.Size = new System.Drawing.Size(303, 26);
            this.txtTeam2.TabIndex = 4;
            this.txtTeam2.Text = "Tìm kiếm đội...";
            this.txtTeam2.DoubleClick += new System.EventHandler(this.txtTeam2_DoubleClick);
            // 
            // lblTeam2
            // 
            this.lblTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam2.ForeColor = System.Drawing.Color.Blue;
            this.lblTeam2.Location = new System.Drawing.Point(553, 29);
            this.lblTeam2.Name = "lblTeam2";
            this.lblTeam2.Size = new System.Drawing.Size(124, 50);
            this.lblTeam2.TabIndex = 4;
            this.lblTeam2.Text = "Đội 2";
            this.lblTeam2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblName
            // 
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(32, 82);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(110, 29);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "Tên";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = false;
            this.btnCancel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancel.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btnCancel.Depth = 0;
            this.btnCancel.HighEmphasis = true;
            this.btnCancel.Icon = null;
            this.btnCancel.Location = new System.Drawing.Point(252, 523);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnCancel.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(146, 36);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Thoát";
            this.btnCancel.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btnCancel.UseAccentColor = false;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.AutoSize = false;
            this.btnSave.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSave.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btnSave.Depth = 0;
            this.btnSave.HighEmphasis = true;
            this.btnSave.Icon = null;
            this.btnSave.Location = new System.Drawing.Point(426, 523);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnSave.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(158, 36);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Lưu lại";
            this.btnSave.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btnSave.UseAccentColor = false;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblTrongTai
            // 
            this.lblTrongTai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrongTai.Location = new System.Drawing.Point(32, 199);
            this.lblTrongTai.Name = "lblTrongTai";
            this.lblTrongTai.Size = new System.Drawing.Size(110, 29);
            this.lblTrongTai.TabIndex = 20;
            this.lblTrongTai.Text = "Trọng tài";
            this.lblTrongTai.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // clbReferees
            // 
            this.clbReferees.DisplayMember = "Fullname";
            this.clbReferees.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbReferees.FormattingEnabled = true;
            this.clbReferees.Location = new System.Drawing.Point(148, 229);
            this.clbReferees.Name = "clbReferees";
            this.clbReferees.Size = new System.Drawing.Size(426, 109);
            this.clbReferees.TabIndex = 7;
            this.clbReferees.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbReferees_ItemCheck);
            this.clbReferees.Click += new System.EventHandler(this.clbReferees_Click);
            // 
            // txtRefereeSearch
            // 
            this.txtRefereeSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtRefereeSearch.ForeColor = System.Drawing.Color.Gray;
            this.txtRefereeSearch.Location = new System.Drawing.Point(148, 199);
            this.txtRefereeSearch.Name = "txtRefereeSearch";
            this.txtRefereeSearch.Size = new System.Drawing.Size(426, 26);
            this.txtRefereeSearch.TabIndex = 6;
            this.txtRefereeSearch.Text = "Tìm kiếm trọng tài...";
            this.txtRefereeSearch.TextChanged += new System.EventHandler(this.txtRefereeSearch_TextChanged);
            this.txtRefereeSearch.Enter += new System.EventHandler(this.txtRefereeSearch_Enter);
            this.txtRefereeSearch.Leave += new System.EventHandler(this.txtRefereeSearch_Leave);
            // 
            // lblMatch_Id
            // 
            this.lblMatch_Id.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMatch_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatch_Id.Location = new System.Drawing.Point(710, 38);
            this.lblMatch_Id.Name = "lblMatch_Id";
            this.lblMatch_Id.Size = new System.Drawing.Size(27, 23);
            this.lblMatch_Id.TabIndex = 30;
            this.lblMatch_Id.Text = "Id";
            this.lblMatch_Id.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMatch_Id.Visible = false;
            // 
            // lblNote
            // 
            this.lblNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(32, 383);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(110, 29);
            this.lblNote.TabIndex = 37;
            this.lblNote.Text = "Ghi chú";
            this.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtnote
            // 
            this.txtnote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtnote.Location = new System.Drawing.Point(148, 383);
            this.txtnote.Multiline = true;
            this.txtnote.Name = "txtnote";
            this.txtnote.Size = new System.Drawing.Size(621, 94);
            this.txtnote.TabIndex = 9;
            // 
            // lblStartDateTime
            // 
            this.lblStartDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDateTime.Location = new System.Drawing.Point(32, 351);
            this.lblStartDateTime.Name = "lblStartDateTime";
            this.lblStartDateTime.Size = new System.Drawing.Size(110, 29);
            this.lblStartDateTime.TabIndex = 39;
            this.lblStartDateTime.Text = "Bắt đầu";
            this.lblStartDateTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpStartDateTime
            // 
            this.dtpStartDateTime.CustomFormat = "dd/MM/yyyy HH:mm";
            this.dtpStartDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dtpStartDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartDateTime.Location = new System.Drawing.Point(148, 351);
            this.dtpStartDateTime.Name = "dtpStartDateTime";
            this.dtpStartDateTime.Size = new System.Drawing.Size(180, 26);
            this.dtpStartDateTime.TabIndex = 7;
            this.dtpStartDateTime.ValueChanged += new System.EventHandler(this.dtpStartDateTime_ValueChanged);
            // 
            // lblEndDateTime
            // 
            this.lblEndDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndDateTime.Location = new System.Drawing.Point(350, 351);
            this.lblEndDateTime.Name = "lblEndDateTime";
            this.lblEndDateTime.Size = new System.Drawing.Size(110, 29);
            this.lblEndDateTime.TabIndex = 40;
            this.lblEndDateTime.Text = "Kết thúc";
            this.lblEndDateTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpEndDateTime
            // 
            this.dtpEndDateTime.CustomFormat = "dd/MM/yyyy HH:mm";
            this.dtpEndDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dtpEndDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndDateTime.Location = new System.Drawing.Point(466, 351);
            this.dtpEndDateTime.Name = "dtpEndDateTime";
            this.dtpEndDateTime.Size = new System.Drawing.Size(180, 26);
            this.dtpEndDateTime.TabIndex = 8;
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(32, 483);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(110, 29);
            this.lblStatus.TabIndex = 38;
            this.lblStatus.Text = "Trạng thái";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbStatus
            // 
            this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Location = new System.Drawing.Point(148, 483);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(200, 28);
            this.cbStatus.TabIndex = 10;
            this.cbStatus.SelectedIndexChanged += new System.EventHandler(this.cbStatus_SelectedIndexChanged);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png, *.gif, *.bmp)|*.jpg;*.jpeg;*.png;*.gif;*.bmp|A" +
    "ll files (*.*)|*.*";
            this.openFileDialog.Title = "Chọn hình ảnh lá cờ";
            // 
            // pbTeam1Flag
            // 
            this.pbTeam1Flag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTeam1Flag.Location = new System.Drawing.Point(148, 114);
            this.pbTeam1Flag.Name = "pbTeam1Flag";
            this.pbTeam1Flag.Size = new System.Drawing.Size(108, 79);
            this.pbTeam1Flag.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbTeam1Flag.TabIndex = 41;
            this.pbTeam1Flag.TabStop = false;
            // 
            // pbTeam2Flag
            // 
            this.pbTeam2Flag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTeam2Flag.Location = new System.Drawing.Point(466, 114);
            this.pbTeam2Flag.Name = "pbTeam2Flag";
            this.pbTeam2Flag.Size = new System.Drawing.Size(108, 79);
            this.pbTeam2Flag.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbTeam2Flag.TabIndex = 43;
            this.pbTeam2Flag.TabStop = false;
            // 
            // lblId1
            // 
            this.lblId1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblId1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId1.Location = new System.Drawing.Point(262, 114);
            this.lblId1.Name = "lblId1";
            this.lblId1.Size = new System.Drawing.Size(27, 23);
            this.lblId1.TabIndex = 44;
            this.lblId1.Text = "Id";
            this.lblId1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblId1.Visible = false;
            // 
            // lblournamentsId1
            // 
            this.lblournamentsId1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblournamentsId1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblournamentsId1.Location = new System.Drawing.Point(295, 114);
            this.lblournamentsId1.Name = "lblournamentsId1";
            this.lblournamentsId1.Size = new System.Drawing.Size(27, 23);
            this.lblournamentsId1.TabIndex = 46;
            this.lblournamentsId1.Text = "Id";
            this.lblournamentsId1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblournamentsId1.Visible = false;
            // 
            // lblournamentsId2
            // 
            this.lblournamentsId2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblournamentsId2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblournamentsId2.Location = new System.Drawing.Point(613, 114);
            this.lblournamentsId2.Name = "lblournamentsId2";
            this.lblournamentsId2.Size = new System.Drawing.Size(27, 23);
            this.lblournamentsId2.TabIndex = 48;
            this.lblournamentsId2.Text = "Id";
            this.lblournamentsId2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblournamentsId2.Visible = false;
            // 
            // lblId2
            // 
            this.lblId2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblId2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId2.Location = new System.Drawing.Point(580, 114);
            this.lblId2.Name = "lblId2";
            this.lblId2.Size = new System.Drawing.Size(27, 23);
            this.lblId2.TabIndex = 47;
            this.lblId2.Text = "Id";
            this.lblId2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblId2.Visible = false;
            // 
            // AddUpdateMatch
            // 
            this.ClientSize = new System.Drawing.Size(787, 584);
            this.Controls.Add(this.lblournamentsId2);
            this.Controls.Add(this.lblId2);
            this.Controls.Add(this.lblournamentsId1);
            this.Controls.Add(this.lblId1);
            this.Controls.Add(this.cbStatus);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.dtpEndDateTime);
            this.Controls.Add(this.lblEndDateTime);
            this.Controls.Add(this.dtpStartDateTime);
            this.Controls.Add(this.lblStartDateTime);
            this.Controls.Add(this.txtnote);
            this.Controls.Add(this.lblMatch_Id);
            this.Controls.Add(this.clbReferees);
            this.Controls.Add(this.txtRefereeSearch);
            this.Controls.Add(this.lblTrongTai);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtTeam2);
            this.Controls.Add(this.lblTeam2);
            this.Controls.Add(this.txtTeam1);
            this.Controls.Add(this.lblTeam1);
            this.Controls.Add(this.pbTeam1Flag);
            this.Controls.Add(this.pbTeam2Flag);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddUpdateMatch";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin trận đấu";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.AddUpdateMatch_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.pbTeam1Flag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTeam2Flag)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private void LoadUsers()
        {
            try
            {
                allUsers = Repository.GetAllUsers().Where(u => u.RoleName != "Admin").ToList(); // Lưu trữ tất cả người dùng để tham khảo
                FilterReferees(""); // Display all users initially
            }
            catch
            {
                clbReferees.Items.Clear();
                clbReferees.Items.Add("No data");
                MessageBox.Show("Không có dữ liệu trọng tài. Vui lòng tạo");
            }
        }

        private void FilterReferees(string searchText)
        {
            // Store currently selected referees before filtering
            var selectedRefereeIds = new List<int>();
            foreach (var item in clbReferees.CheckedItems)
            {
                if (item is UserModel user)
                {
                    selectedRefereeIds.Add(user.Id);
                }
            }

            clbReferees.Items.Clear();

            // Set the DisplayMember to show the Fullname property
            clbReferees.DisplayMember = "Fullname";

            // Check if the search text is the placeholder text
            if (searchText == "Tìm kiếm trọng tài...")
            {
                searchText = "";
            }

            List<UserModel> usersToShow;
            if (string.IsNullOrWhiteSpace(searchText))
            {
                // If no search text, show all users
                usersToShow = allUsers;
            }
            else
            {
                // Filter users based on search text
                usersToShow = allUsers.Where(u => 
                    u.Fullname != null && 
                    u.Fullname.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            }

            // Add users to the list and restore checked state
            foreach (var user in usersToShow)
            {
                bool isChecked = selectedRefereeIds.Contains(user.Id);
                clbReferees.Items.Add(user, isChecked);
            }
        }

        private void txtRefereeSearch_TextChanged(object sender, EventArgs e)
        {
            FilterReferees(txtRefereeSearch.Text.Trim());
        }

        private void txtRefereeSearch_Enter(object sender, EventArgs e)
        {
            if (txtRefereeSearch.Text == "Tìm kiếm trọng tài...")
            {
                txtRefereeSearch.Text = "";
                txtRefereeSearch.ForeColor = System.Drawing.Color.Black;
            }
        }

        private void txtRefereeSearch_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRefereeSearch.Text))
            {
                txtRefereeSearch.Text = "Tìm kiếm trọng tài...";
                txtRefereeSearch.ForeColor = System.Drawing.Color.Gray;
            }
        }

        private void cbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if the selected status is "In Progress" and disable referee controls
            if (cbStatus.SelectedValue != null)
            {
                string selectedStatus = cbStatus.SelectedValue.ToString();
                if (selectedStatus == MatchStatusConfig.Status.InProgress)
                {
                    // Disable referee selection when match is in progress
                    clbReferees.Enabled = false;
                    txtRefereeSearch.Enabled = false;
                    txtRefereeSearch.Text = "Tìm kiếm trọng tài...";
                    txtRefereeSearch.ForeColor = System.Drawing.Color.Gray;
                }
                else
                {
                    // Enable referee selection for other statuses
                    clbReferees.Enabled = true;
                    txtRefereeSearch.Enabled = true;
                    
                    // Restore placeholder text if search box is empty
                    if (string.IsNullOrWhiteSpace(txtRefereeSearch.Text))
                    {
                        txtRefereeSearch.Text = "Tìm kiếm trọng tài...";
                        txtRefereeSearch.ForeColor = System.Drawing.Color.Gray;
                    }
                }
            }
        }

        private void LoadStatus()
        {
            cbStatus.Items.Clear();

            // Kiểm tra xem có phải tạo mới hay không
            bool isNewMatch = string.IsNullOrWhiteSpace(currentMatch.Id);

            if (isNewMatch)
            {
                // Tạo mới: chỉ có 1 option "Chưa bắt đầu"
                cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.NotStarted, Value = MatchStatusConfig.Status.NotStarted });
            }
            else
            {
                // Edit mode: load status options dựa trên trạng thái hiện tại
                string currentStatus = currentMatch.Status ?? MatchStatusConfig.Status.NotStarted;

                switch (currentStatus)
                {
                    case MatchStatusConfig.Status.NotStarted:
                        // Nếu đang ở "Chưa bắt đầu" thì có thể chuyển sang "Đang diễn ra"
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.NotStarted, Value = MatchStatusConfig.Status.NotStarted });
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.InProgress, Value = MatchStatusConfig.Status.InProgress });
                        break;

                    case MatchStatusConfig.Status.InProgress:
                        // Nếu đang ở "Đang diễn ra" thì có thể chuyển sang "Đã kết thúc"
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.InProgress, Value = MatchStatusConfig.Status.InProgress });

                        // Kiểm tra nếu trận đấu có nhiều hơn 2 record thì không cho chuyển status "Đã kết thúc"
                        var matchSetsCount = Repository.GetMatchSetsByMatchId(currentMatch.Id).Count;
                        if (matchSetsCount == 1)
                        {
                            cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.Finished, Value = MatchStatusConfig.Status.Finished });
                        }
                        break;

                    case MatchStatusConfig.Status.Finished:
                        // Nếu đang ở "Đã kết thúc" thì chỉ có thể giữ nguyên
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.Finished, Value = MatchStatusConfig.Status.Finished });
                        break;

                    default:
                        // Fallback: hiển thị tất cả options
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.NotStarted, Value = MatchStatusConfig.Status.NotStarted });
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.InProgress, Value = MatchStatusConfig.Status.InProgress });
                        cbStatus.Items.Add(new { Text = MatchStatusConfig.StatusText.Finished, Value = MatchStatusConfig.Status.Finished });
                        break;
                }
            }

            cbStatus.DisplayMember = "Text";
            cbStatus.ValueMember = "Value";

            // Set selected index dựa trên trạng thái hiện tại
            if (!isNewMatch && !string.IsNullOrEmpty(currentMatch.Status))
            {
                for (int i = 0; i < cbStatus.Items.Count; i++)
                {
                    var item = cbStatus.Items[i];
                    var valueProperty = item.GetType().GetProperty("Value");
                    if (valueProperty != null && valueProperty.GetValue(item).ToString() == currentMatch.Status)
                    {
                        cbStatus.SelectedIndex = i;
                        break;
                    }
                }
            }
            else
            {
                cbStatus.SelectedIndex = 0; // Default to first option
            }
        }

        private void PopulateFromModel(MatchModel m)
        {
            lblMatch_Id.Text = m.Id.ToString();
            txtTeam1.Text = m.Team1;
            txtTeam2.Text = m.Team2;
            //nScore1.Value = m.Score1;
            //nScore2.Value = m.Score2;

            // Load start and end datetime
            if (m.Start.HasValue)
            {
                dtpStartDateTime.Value = m.Start.Value;
            }
            if (m.End.HasValue)
            {
                dtpEndDateTime.Value = m.End.Value;
            }

            // Handle single referee selection
            if (m.RefereeIds != null && m.RefereeIds.Count > 0)
            {
                // Select only the first referee in the CheckedListBox
                for (int i = 0; i < clbReferees.Items.Count; i++)
                {
                    if (clbReferees.Items[i] is UserModel user)
                    {
                        if (m.RefereeIds.Contains(user.Id))
                        {
                            clbReferees.SetItemChecked(i, true);
                            break; // Only select the first match
                        }
                    }
                }
            }
            else if (m.RefereeId.HasValue)
            {
                // Fallback to single referee for backward compatibility
                for (int i = 0; i < clbReferees.Items.Count; i++)
                {
                    if (clbReferees.Items[i] is UserModel user)
                    {
                        if (user.Id == m.RefereeId.Value)
                        {
                            clbReferees.SetItemChecked(i, true);
                            break;
                        }
                    }
                }
            }

            txtnote.Text = m.Note;
            this.Text = "Thông tin trận đấu: " + txtTeam1.Text + " - " + txtTeam2.Text;
            var matchSetsCount = Repository.GetMatchSetsByMatchId(currentMatch.Id).Count;
            if (matchSetsCount >= 2)
            {
                clbReferees.Enabled = false;
                txtRefereeSearch.Enabled = false; // Disable search when referees are disabled
            }
            
            // Check if match status is "In Progress" and disable referees
            if (m.Status == MatchStatusConfig.Status.InProgress)
            {
                clbReferees.Enabled = false;
                txtRefereeSearch.Enabled = false;
                txtRefereeSearch.Text = "Tìm kiếm trọng tài...";
                txtRefereeSearch.ForeColor = System.Drawing.Color.Gray;
            }
            
            // Load flag images if they exist
            LoadFlagImages(m);
        }

        public AddUpdateMatch(int tournament_id, string id = "")
        {
            InitializeComponent();
            pbTeam1Flag.SizeMode = PictureBoxSizeMode.Zoom;
            pbTeam2Flag.SizeMode = PictureBoxSizeMode.Zoom;
            // Set default start datetime to current time
            dtpStartDateTime.Value = DateTime.Now;
            // Set default end datetime to 4 hours later
            dtpEndDateTime.Value = DateTime.Now.AddHours(4);
            
            // Initialize placeholder text for search box
            txtRefereeSearch.Text = "Tìm kiếm trọng tài...";
            txtRefereeSearch.ForeColor = System.Drawing.Color.Gray;
            
            LoadUsers();
            // Load tournament information to set date constraints
            var tournament = Repository.GetAllTournamentsById(tournament_id);
            if (tournament != null && tournament.End.HasValue)
            {
                // Set the maximum date for the end date picker to the tournament's end date
                // But ensure it's at 23:59:59 of that day
                var maxEndDate = tournament.End.Value.Date.AddHours(23).AddMinutes(59).AddSeconds(59);
                var maxStartDate = tournament.Start.Value.Date.AddHours(00).AddMinutes(00).AddSeconds(00);
                dtpEndDateTime.MaxDate = maxEndDate;
                dtpStartDateTime.MaxDate = maxEndDate;
                dtpStartDateTime.MinDate = maxStartDate;
                dtpEndDateTime.MinDate = maxStartDate;
            }

            if (id != "")
            {
                // edit mode
                currentMatch = Repository.GetMatchById(id);
                if (currentMatch != null)
                {
                    PopulateFromModel(currentMatch);
                    LoadStatus(); // Load status after setting currentMatch
                }
                else
                {
                    MessageBox.Show("Không tìm thấy trận đấu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    currentMatch = new MatchModel();
                    currentMatch.TournamentId = tournament_id;
                    lblMatch_Id.Text = "";
                    LoadStatus(); // Load status after setting currentMatch
                }
            }
            else
            {
                // create mode
                currentMatch = new MatchModel();
                currentMatch.TournamentId = tournament_id;
                lblMatch_Id.Text = "";
                LoadStatus(); // Load status after setting currentMatch
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // validation
            if (txtTeam1.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhận tên đội 1", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTeam1.Focus();
                return;
            }
            if (txtTeam2.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhận tên đội 2", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTeam2.Focus();
                return;
            }
            if (txtTeam1.Text.Trim().ToUpper() == txtTeam2.Text.Trim().ToUpper())
            {
                MessageBox.Show("Trùng tên đội", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTeam1.Focus();
                return;
            }

            // Check if at least one referee is selected
            var selectedReferees = new List<UserModel>();
            foreach (var item in clbReferees.CheckedItems)
            {
                if (item is UserModel user)
                {
                    selectedReferees.Add(user);
                }
            }

            if (selectedReferees.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn một trọng tài cho trận đấu", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clbReferees.Focus();
                return;
            }

            // Kiểm tra thời gian bắt đầu và kết thúc có nằm trong khoảng thời gian của giải đấu không
            if (currentMatch.TournamentId.HasValue)
            {
                var tournament = Repository.GetAllTournamentsById(currentMatch.TournamentId.Value);
                // Set the MatchClassId from the tournament
                currentMatch.MatchClassId = tournament.match_class_id;
                currentMatch.MatchClassName = tournament.match_class_name;
                var start = tournament.Start.Value.Date.AddHours(00).AddMinutes(00).AddSeconds(00);
                var end = tournament.End.Value.Date.AddHours(23).AddMinutes(59).AddSeconds(59);
                if (tournament != null && tournament.Start.HasValue && tournament.End.HasValue)
                {
                    if (dtpStartDateTime.Value < start || dtpStartDateTime.Value > end)
                    {
                        MessageBox.Show($"Thời gian bắt đầu ({dtpStartDateTime.Value:dd/MM/yyyy HH:mm}) phải nằm trong khoảng thời gian của giải đấu ({tournament.Start.Value:dd/MM/yyyy HH:mm} - {tournament.End.Value:dd/MM/yyyy HH:mm})",
                                      "Thời gian không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        dtpStartDateTime.Focus();
                        return;
                    }

                    if (dtpEndDateTime.Value < start || dtpEndDateTime.Value > end)
                    {
                        MessageBox.Show($"Thời gian kết thúc ({dtpEndDateTime.Value:dd/MM/yyyy HH:mm}) phải nằm trong khoảng thời gian của giải đấu ({tournament.Start.Value:dd/MM/yyyy HH:mm} - {tournament.End.Value:dd/MM/yyyy HH:mm})",
                                      "Thời gian không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        dtpEndDateTime.Focus();
                        return;
                    }
                }
            }

            // Check if any selected referee is busy during the match time period
            if (string.IsNullOrWhiteSpace(currentMatch.Id))
            {
                var selectedRefereeIds = selectedReferees.Select(r => r.Id).ToList();
                var busyReferees = Repository.GetBusyRefereesInfoInTimeRange(selectedRefereeIds, dtpStartDateTime.Value, dtpEndDateTime.Value);

                if (busyReferees.Count > 0)
                {
                    string busyNames = string.Join(", ", busyReferees);

                    MessageBox.Show($"Trọng tài {busyNames} đang bận bắt trận đấu khác trong thời gian từ {dtpStartDateTime.Value:dd/MM/yyyy HH:mm} đến {dtpEndDateTime.Value:dd/MM/yyyy HH:mm}. Vui lòng chọn trọng tài khác.",
                                  "Trọng tài đang bận", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    clbReferees.Focus();
                    return;
                }
            }

            // map
            currentMatch.Team1 = txtTeam1.Text.Trim();
            currentMatch.Team2 = txtTeam2.Text.Trim();
            //currentMatch.Score1 = int.Parse(nScore1.Value.ToString());
            //currentMatch.Score2 = int.Parse(nScore2.Value.ToString());
            // Always save time as 00:00
            currentMatch.Time = "00:00";

            // Set start and end datetime
            currentMatch.Start = dtpStartDateTime.Value;
            currentMatch.End = dtpEndDateTime.Value;

            // Handle multiple referees
            currentMatch.RefereeIds = new List<int>();
            currentMatch.RefereeNames = new List<string>();
            currentMatch.Status = cbStatus.SelectedValue?.ToString();

            foreach (var referee in selectedReferees)
            {
                currentMatch.RefereeIds.Add(referee.Id);
                currentMatch.RefereeNames.Add(referee.Name);
            }

            // For backward compatibility, set the first referee as the main referee
            if (selectedReferees.Count > 0)
            {
                currentMatch.RefereeId = selectedReferees[0].Id;
                currentMatch.RefereeName = selectedReferees[0].Name;
            }

            currentMatch.Note = txtnote.Text.Trim();

            // Set status from combobox
            if (cbStatus.SelectedItem != null)
            {
                var selectedItem = cbStatus.SelectedItem;
                var valueProperty = selectedItem.GetType().GetProperty("Value");
                if (valueProperty != null)
                {
                    currentMatch.Status = valueProperty.GetValue(selectedItem).ToString();
                }
            }

            try
            {
                if (string.IsNullOrWhiteSpace(currentMatch.Id))
                {
                    currentMatch.Id = Repository.GenerateMatchCode();
                    Repository.AddMatch(currentMatch);

                    // Auto-create the first match set (Hiệp 1) for the newly added match
                    if (currentMatch.TournamentId.HasValue)
                    {
                        var tournament = Repository.GetAllTournamentsById(currentMatch.TournamentId.Value);
                        if (tournament != null)
                        {
                            // Determine period name based on match class
                            string firstPeriodName = GetFirstPeriodName(tournament.match_class_id);

                            var firstSet = new MatchsetModel
                            {
                                MatchId = currentMatch.Id,
                                Team1 = currentMatch.Team1,
                                Team2 = currentMatch.Team2,
                                Score1 = 0,
                                Score2 = 0,
                                Time = "00:00",
                                Note = "",
                                Status = MatchStatusConfig.Status.InProgress, // Active
                                RefereeId = (currentMatch.RefereeIds != null && currentMatch.RefereeIds.Count > 0) ? (int?)currentMatch.RefereeIds[0] : null,
                                RefereeName = currentMatch.RefereeName,
                                ClassSetsName = firstPeriodName, // Use "Hiệp 1" instead of firstClassSet.Name
                                TournamentId = currentMatch.TournamentId,
                                TournamentName = currentMatch.TournamentName,
                                MatchClassId = currentMatch.MatchClassId,
                                MatchClassName = currentMatch.MatchClassName
                            };
                            Repository.AddMatchSet(firstSet);
                        }
                    }

                    MessageBox.Show("Tạo mới thành công.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // Kiểm tra nếu chuyển sang trạng thái "Đã kết thúc"
                    if (currentMatch.Status == MatchStatusConfig.Status.Finished)
                    {
                        // Cập nhật tất cả MatchSets của trận đấu này sang trạng thái "Đã kết thúc"
                        var allMatchSets = Repository.GetMatchSetsByMatchId(currentMatch.Id);
                        foreach (var matchSet in allMatchSets)
                        {
                            if (matchSet.Status != MatchStatusConfig.Status.Finished)
                            {
                                Repository.UpdateMatchSetStatus(currentMatch.Id, matchSet.Id, MatchStatusConfig.Status.Finished);
                            }
                        }
                    }

                    Repository.UpdateMatch(currentMatch);
                    MessageBox.Show("Cập nhật thành công.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lưu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void clbReferees_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // If the user is checking an item, uncheck all other items
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < clbReferees.Items.Count; i++)
                {
                    if (i != e.Index && clbReferees.GetItemChecked(i))
                    {
                        clbReferees.SetItemChecked(i, false);
                    }
                }
            }
        }

        private void clbReferees_Click(object sender, EventArgs e)
        {
            // Get the index of the clicked item
            int index = clbReferees.IndexFromPoint(clbReferees.PointToClient(Cursor.Position));

            if (index >= 0)
            {
                // Toggle the checked state of the clicked item
                bool isCurrentlyChecked = clbReferees.GetItemChecked(index);
                clbReferees.SetItemChecked(index, !isCurrentlyChecked);
            }
        }

        private void btnUpdateTime_Click(object sender, EventArgs e)
        {
            UpdateTime up = new UpdateTime();
            up.ShowDialog();
        }

        private string GetFirstPeriodName(int matchClassId)
        {
            // Get match class info to determine period type
            var matchClass = Repository.GetMatchClassById(matchClassId);
            if (matchClass != null)
            {
                switch (matchClass.PeriodType?.ToLower())
                {
                    case "half":
                        return "Hiệp 1";
                    case "quarter":
                        return "Hiệp nhỏ 1";
                    case "set":
                        return "Set 1";
                    default:
                        return "Hiệp 1";
                }
            }
            else
            {
                return "Hiệp 1";
            }
        }

        private void dtpStartDateTime_ValueChanged(object sender, EventArgs e)
        {
            // Kiểm tra xem currentMatch có null không để tránh lỗi khi form đang khởi tạo
            if (currentMatch == null)
                return;

            // Khi thay đổi thời gian bắt đầu, tự động cập nhật thời gian kết thúc (+4 tiếng)
            var newEndTime = dtpStartDateTime.Value.AddHours(4);

            // Kiểm tra xem thời gian kết thúc có vượt quá phạm vi giải đấu không
            if (currentMatch.TournamentId.HasValue)
            {
                var tournament = Repository.GetAllTournamentsById(currentMatch.TournamentId.Value);
                if (tournament != null && tournament.End.HasValue)
                {
                    if (newEndTime > tournament.End.Value)
                    {
                        // Nếu vượt quá, đặt thời gian kết thúc = thời gian kết thúc của giải đấu
                        dtpEndDateTime.Value = tournament.End.Value;
                        return;
                    }
                }
            }

            dtpEndDateTime.Value = newEndTime;
        }

        private void dtpEndDateTime_ValueChanged(object sender, EventArgs e)
        {
            // Kiểm tra xem currentMatch có null không để tránh lỗi khi form đang khởi tạo
            if (currentMatch == null)
                return;

            // Kiểm tra xem thời gian kết thúc có nằm trong khoảng thời gian của giải đấu không
            if (currentMatch.TournamentId.HasValue)
            {
                var tournament = Repository.GetAllTournamentsById(currentMatch.TournamentId.Value);
                if (tournament != null && tournament.Start.HasValue && tournament.End.HasValue)
                {
                    if (dtpEndDateTime.Value < tournament.Start.Value || dtpEndDateTime.Value > tournament.End.Value)
                    {
                        MessageBox.Show($"Thời gian kết thúc ({dtpEndDateTime.Value:dd/MM/yyyy HH:mm}) phải nằm trong khoảng thời gian của giải đấu ({tournament.Start.Value:dd/MM/yyyy HH:mm} - {tournament.End.Value:dd/MM/yyyy HH:mm})",
                                      "Thời gian không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                        // Reset về thời gian kết thúc của giải đấu nếu vượt quá
                        if (dtpEndDateTime.Value > tournament.End.Value)
                        {
                            dtpEndDateTime.Value = tournament.End.Value;
                        }
                        else if (dtpEndDateTime.Value < tournament.Start.Value)
                        {
                            dtpEndDateTime.Value = tournament.Start.Value.AddHours(1); // Ít nhất 1 tiếng
                        }
                        return;
                    }
                }
            }

            // Kiểm tra xem thời gian kết thúc có sau thời gian bắt đầu không
            if (dtpEndDateTime.Value <= dtpStartDateTime.Value)
            {
                MessageBox.Show("Thời gian kết thúc phải sau thời gian bắt đầu",
                              "Thời gian không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dtpEndDateTime.Value = dtpStartDateTime.Value.AddHours(1); // Ít nhất 1 tiếng sau
                return;
            }
        }

        private void btnSelectTeam1Flag_Click(object sender, EventArgs e)
        {
            SelectFlagImage(1);
        }

        private void btnSelectTeam2Flag_Click(object sender, EventArgs e)
        {
            SelectFlagImage(2);
        }

        private void SelectFlagImage(int teamNumber)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string selectedFilePath = openFileDialog.FileName;
                    string fileName = Path.GetFileName(selectedFilePath);
                    string fileExtension = Path.GetExtension(fileName);

                    // Tạo tên file mới với timestamp để tránh trùng lặp
                    string newFileName = $"team{teamNumber}_{DateTime.Now:yyyyMMddHHmmss}{fileExtension}";
                    string flagsDirectory = Path.Combine(Application.StartupPath, "Resources", "Flags");

                    // Tạo thư mục nếu chưa tồn tại
                    if (!Directory.Exists(flagsDirectory))
                    {
                        Directory.CreateDirectory(flagsDirectory);
                    }

                    string destinationPath = Path.Combine(flagsDirectory, newFileName);

                    // Copy file ảnh vào thư mục Flags
                    File.Copy(selectedFilePath, destinationPath, true);

                    // Hiển thị ảnh trong PictureBox
                    if (teamNumber == 1)
                    {
                        pbTeam1Flag.Image = Image.FromFile(destinationPath);
                        currentMatch.Team1Flag = newFileName;
                    }
                    else
                    {
                        pbTeam2Flag.Image = Image.FromFile(destinationPath);
                        currentMatch.Team2Flag = newFileName;
                    }

                    MessageBox.Show($"Đã chọn và lưu hình ảnh lá cờ cho đội {teamNumber}", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi chọn hình ảnh: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadFlagImages(MatchModel match)
        {
            try
            {
                string flagsDirectory = Path.Combine(Application.StartupPath, "Resources", "Flags");

                // Load Team1 flag
                if (!string.IsNullOrEmpty(match.Team1Flag))
                {
                    string team1FlagPath = Path.Combine(flagsDirectory, match.Team1Flag);
                    if (File.Exists(team1FlagPath))
                    {
                        pbTeam1Flag.Image = Image.FromFile(team1FlagPath);
                    }
                }

                // Load Team2 flag
                if (!string.IsNullOrEmpty(match.Team2Flag))
                {
                    string team2FlagPath = Path.Combine(flagsDirectory, match.Team2Flag);
                    if (File.Exists(team2FlagPath))
                    {
                        pbTeam2Flag.Image = Image.FromFile(team2FlagPath);
                    }
                }
            }
            catch (Exception)
            {
                // Silently handle errors when loading flag images
                // This prevents the form from crashing if flag images are missing
            }
        }
        private void AddUpdateMatch_Paint(object sender, PaintEventArgs e)
        {
            int radius = 30; // bo góc
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Bo góc form
            GraphicsPath path = new GraphicsPath();
            path.StartFigure();
            path.AddArc(new Rectangle(0, 0, radius, radius), 180, 90);
            path.AddArc(new Rectangle(this.Width - radius, 0, radius, radius), 270, 90);
            path.AddArc(new Rectangle(this.Width - radius, this.Height - radius, radius, radius), 0, 90);
            path.AddArc(new Rectangle(0, this.Height - radius, radius, radius), 90, 90);
            path.CloseFigure();

            // Áp dụng bo góc
            this.Region = new Region(path);

            // Viền nhẹ (giống web)
            using (Pen borderPen = new Pen(Color.LightGray, 1))
                g.DrawPath(borderPen, path);
        }

        private void txtTeam1_DoubleClick(object sender, EventArgs e)
        {
            TeamsSearchForm frm = new TeamsSearchForm((int)currentMatch.TournamentId);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                var teams = Repository.GetTeamById(frm.team_Id, frm.tournament_Id);
                lblId1.Text = teams.Id.ToString();
                lblournamentsId1.Text = teams.TournamentsId.ToString();

                txtTeam1.Text = teams.Name;
                LoadFlagToPictureBox(teams.Flag, pbTeam1Flag);
            }
            
        }

        private void txtTeam2_DoubleClick(object sender, EventArgs e)
        {
            TeamsSearchForm frm = new TeamsSearchForm((int)currentMatch.TournamentId);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                var teams = Repository.GetTeamById(frm.team_Id, frm.tournament_Id);
                lblId2.Text = teams.Id.ToString();
                lblournamentsId2.Text= teams.TournamentsId.ToString();

                txtTeam2.Text = teams.Name;
                LoadFlagToPictureBox(teams.Flag, pbTeam2Flag);
            }
        }
        private void LoadFlagToPictureBox(byte[] imageBytes, PictureBox pictureBox)
        {
            if (imageBytes == null || imageBytes.Length == 0)
            {
                pictureBox.Image = null;
                return;
            }

            using (var ms = new MemoryStream(imageBytes))
            {
                pictureBox.Image?.Dispose();
                pictureBox.Image = new Bitmap(Image.FromStream(ms));
            }
        }
    }
}

