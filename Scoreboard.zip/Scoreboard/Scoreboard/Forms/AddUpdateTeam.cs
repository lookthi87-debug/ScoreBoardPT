using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using MaterialSkin.Controls;
using Scoreboard.Config;
using Scoreboard.Data;
using Scoreboard.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Scoreboard
{
    public class AddUpdateTeam : Form
    {
        private System.Windows.Forms.TextBox txtTeam1;
        private Label lblName;
        private MaterialButton btnCancel;
        private MaterialButton btnSave;
        private Label lblNote;
        private System.Windows.Forms.TextBox txtnote;
        private PictureBox pbTeam1Flag;
        private Label label1;
        private OpenFileDialog openFileDialog;
        private TeamModel currentTeam;
        private void InitializeComponent()
        {
            this.txtTeam1 = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.btnCancel = new MaterialSkin.Controls.MaterialButton();
            this.btnSave = new MaterialSkin.Controls.MaterialButton();
            this.lblNote = new System.Windows.Forms.Label();
            this.txtnote = new System.Windows.Forms.TextBox();
            this.pbTeam1Flag = new System.Windows.Forms.PictureBox();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbTeam1Flag)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTeam1
            // 
            this.txtTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTeam1.Location = new System.Drawing.Point(125, 36);
            this.txtTeam1.MaxLength = 100;
            this.txtTeam1.Name = "txtTeam1";
            this.txtTeam1.Size = new System.Drawing.Size(303, 26);
            this.txtTeam1.TabIndex = 3;
            // 
            // lblName
            // 
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(9, 36);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(110, 29);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "Tên";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = false;
            this.btnCancel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancel.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btnCancel.Depth = 0;
            this.btnCancel.HighEmphasis = true;
            this.btnCancel.Icon = null;
            this.btnCancel.Location = new System.Drawing.Point(228, 414);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnCancel.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(146, 36);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Thoát";
            this.btnCancel.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btnCancel.UseAccentColor = false;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.AutoSize = false;
            this.btnSave.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSave.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btnSave.Depth = 0;
            this.btnSave.HighEmphasis = true;
            this.btnSave.Icon = null;
            this.btnSave.Location = new System.Drawing.Point(402, 414);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnSave.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(158, 36);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Lưu lại";
            this.btnSave.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btnSave.UseAccentColor = false;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblNote
            // 
            this.lblNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(9, 298);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(110, 29);
            this.lblNote.TabIndex = 37;
            this.lblNote.Text = "Ghi chú";
            this.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtnote
            // 
            this.txtnote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtnote.Location = new System.Drawing.Point(125, 298);
            this.txtnote.Multiline = true;
            this.txtnote.Name = "txtnote";
            this.txtnote.Size = new System.Drawing.Size(621, 94);
            this.txtnote.TabIndex = 9;
            // 
            // pbTeam1Flag
            // 
            this.pbTeam1Flag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTeam1Flag.Location = new System.Drawing.Point(125, 68);
            this.pbTeam1Flag.Name = "pbTeam1Flag";
            this.pbTeam1Flag.Size = new System.Drawing.Size(303, 224);
            this.pbTeam1Flag.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbTeam1Flag.TabIndex = 41;
            this.pbTeam1Flag.TabStop = false;
            this.pbTeam1Flag.Click += new System.EventHandler(this.pbTeam1Flag_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png, *.gif, *.bmp)|*.jpg;*.jpeg;*.png;*.gif;*.bmp|A" +
    "ll files (*.*)|*.*";
            this.openFileDialog.Title = "Chọn hình ảnh lá cờ";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 29);
            this.label1.TabIndex = 44;
            this.label1.Text = "Logo";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AddUpdateTeam
            // 
            this.ClientSize = new System.Drawing.Size(766, 479);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.txtnote);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtTeam1);
            this.Controls.Add(this.pbTeam1Flag);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddUpdateTeam";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin trận đấu";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.AddUpdateMatch_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.pbTeam1Flag)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private void PopulateFromModel(TeamModel t)
        {
            lblTeam1.Text = t.NameTeam1;
            lblTeam2.Text = t.NameTeam2;
            txtnote.Text = t.Note;
            LoadFlagImages(t);
        }
        public AddUpdateTeam(int tournament_id, int id = -1)
        {
            InitializeComponent();

            if (id != -1)
            {
                // edit mode
                currentTeam = Repository.GetTeamById(id, tournament_id);
                if (currentTeam != null)
                    PopulateFromModel(currentTeam);
                else
                {
                    MessageBox.Show("Không tìm thấy dữ liệu", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    currentTeam = new TeamModel();
                    currentTeam.Id = -1;
                }
            }
            else
            {
                // create mode
                currentTeam = new TeamModel();
                currentTeam.Id = -1;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // validation
            if (txtTeam1.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhận tên đội 1", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTeam1.Focus();
                return;
            }
            if (txtTeam2.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhận tên đội 2", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTeam2.Focus();
                return;
            }

            try
            {
                currentTeam.NameTeam1 = txtTeam1.Text;
                currentTeam.NameTeam2 = txtTeam2.Text;
                currentTeam.Note = txtnote.Text;
                if (currentTeam.Id == -1)
                {
                    Repository.AddTeam(currentTeam);
                    MessageBox.Show("Tạo mới thành công.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    Repository.UpdateTeam(currentTeam);
                    MessageBox.Show("Cập nhật thành công.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lưu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnUpdateTime_Click(object sender, EventArgs e)
        {
            UpdateTime up = new UpdateTime();
            up.ShowDialog();
        }

        private void btnSelectTeam1Flag_Click(object sender, EventArgs e)
        {
            SelectFlagImage(1);
        }

        private void btnSelectTeam2Flag_Click(object sender, EventArgs e)
        {
            SelectFlagImage(2);
        }

        private void SelectFlagImage(int teamNumber)
        {
            if (openFileDialog.ShowDialog() != DialogResult.OK)
                return;

            try
            {
                byte[] imageBytes = File.ReadAllBytes(openFileDialog.FileName);

                using (var ms = new MemoryStream(imageBytes))
                {
                    Image img = Image.FromStream(ms);

                    if (teamNumber == 1)
                    {
                        pbTeam1Flag.Image?.Dispose();
                        pbTeam1Flag.Image = new Bitmap(img);
                        currentTeam.Team1Flag = imageBytes; // LƯU DB
                    }
                    else
                    {
                        pbTeam2Flag.Image?.Dispose();
                        pbTeam2Flag.Image = new Bitmap(img);
                        currentTeam.Team2Flag = imageBytes; // LƯU DB
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi chọn ảnh:\n" + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFlagImages(TeamModel team)
        {
            try
            {
                if (team.Team1Flag != null)
                {
                    using (var ms = new MemoryStream(team.Team1Flag))
                    {
                        pbTeam1Flag.Image = Image.FromStream(ms);
                    }
                }

                if (team.Team2Flag != null)
                {
                    using (var ms = new MemoryStream(team.Team2Flag))
                    {
                        pbTeam2Flag.Image = Image.FromStream(ms);
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        private void AddUpdateMatch_Paint(object sender, PaintEventArgs e)
        {
            int radius = 30; // bo góc
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Bo góc form
            GraphicsPath path = new GraphicsPath();
            path.StartFigure();
            path.AddArc(new Rectangle(0, 0, radius, radius), 180, 90);
            path.AddArc(new Rectangle(this.Width - radius, 0, radius, radius), 270, 90);
            path.AddArc(new Rectangle(this.Width - radius, this.Height - radius, radius, radius), 0, 90);
            path.AddArc(new Rectangle(0, this.Height - radius, radius, radius), 90, 90);
            path.CloseFigure();

            // Áp dụng bo góc
            this.Region = new Region(path);

            // Viền nhẹ (giống web)
            using (Pen borderPen = new Pen(System.Drawing.Color.LightGray, 1))
                g.DrawPath(borderPen, path);
        }

        private void pbTeam1Flag_Click(object sender, EventArgs e)
        {
            SelectFlagImage(1);
        }

        private void pbTeam2Flag_Click(object sender, EventArgs e)
        {
            SelectFlagImage(2);
        }
    }
}

